package com.example.myapplicationutn007.SQLite;

public class Usuario {
    public int Id;
    public String Usuario;
    public String Contrasenia;

    public Usuario(int id, String usuario, String contrasenia) {
        Id = id;
        Usuario = usuario;
        Contrasenia = contrasenia;
    }
}
